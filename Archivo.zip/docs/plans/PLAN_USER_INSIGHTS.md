# Plan — User Insights Layer

Capa única de métricas computadas sobre los movimientos del user. Alimenta
todas las features que hoy calculan agregados on-the-fly:

- Welcome report post-Fintoc exchange
- Resumen nocturno de Gus (`PLAN_GUS_PROACTIVO` Fase 1)
- Baseline del detector de anomalías (Fase 2)
- Contexto para Gus cuando el user pregunta "cuánto gasto en X"
- Auto-fill de budgets durante onboarding (si hay historia)

**Principio rector:** un solo pipeline de cómputo, una sola tabla de
resultado. Todo lo demás la consume.

---

## Problema que resuelve

Hoy cada feature que necesita "promedio por categoría", "top categorías",
"gasto semanal pico" corre su propia agregación SQL. Consecuencias:

1. Duplicación de lógica (variantes sutiles en filtros, date ranges, etc.)
2. Costo de DB multiplicado (la misma agregación 4 veces)
3. Inconsistencias: el nightly summary ve una cosa, el anomaly detector
   otra, el user le pregunta a Gus y obtiene un tercer número
4. Imposible "mostrar mis insights" en el dashboard sin otro round-trip
   caro
5. No hay forma de ver evolución temporal (snapshots históricos)

Con `user_insights`: compute once, read many.

---

## Transfer-awareness desde día 1

**Contexto:** un fix mayor pendiente (`PLAN_ACCOUNT_TRANSFERS.md`) es
distinguir transferencias entre cuentas propias del user (no son ni
gasto ni ingreso — son movimiento neutro).

Mientras eso no esté implementado, el insight engine se construye
**preparado** para filtrarlas:

- Todas las queries agregadas incluyen `AND is_internal_transfer = false`
- Si la columna no está poblada (default `false`), todo pasa como hoy
- El día que activemos el detector de transferencias, los insights se
  auto-corrigen sin cambiar código del engine

Cambios de schema preparatorios (van en la misma migration de este plan):

```sql
ALTER TABLE transactions
  ADD COLUMN IF NOT EXISTS is_internal_transfer boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS paired_transaction_id uuid NULL
    REFERENCES transactions(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_transactions_transfer
  ON transactions(user_id, is_internal_transfer)
  WHERE is_internal_transfer = true;
```

Costo: 1 booleano + 1 FK nullable. ~10 bytes por row extra. Cero riesgo.

Stub para el detector:

```typescript
// backend/src/bot/v3/functions/shared/transfer-detector.ts
export async function isInternalTransfer(
  supabase: SupabaseClient,
  userId: string,
  tx: TransactionRow,
): Promise<{ isTransfer: boolean; pairedId: string | null }> {
  // TODO: PLAN_ACCOUNT_TRANSFERS.md
  return { isTransfer: false, pairedId: null };
}
```

Se llama en `FintocSyncService.persistMovements()` antes del insert. Por
ahora siempre devuelve false — cuando llegue el plan real, solo se cambia
la lógica interna, no los call-sites.

---

## Schema

### Tabla principal — `user_insights`

Una fila por user. Se upsertea en cada recompute.

```sql
CREATE TABLE user_insights (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,

  -- Período cubierto por el snapshot actual
  period_start date NOT NULL,
  period_end date NOT NULL,

  -- Métricas agregadas
  avg_monthly_spend numeric NOT NULL DEFAULT 0,
  avg_monthly_income numeric NOT NULL DEFAULT 0,
  avg_daily_spend numeric NOT NULL DEFAULT 0,
  total_expense_count int NOT NULL DEFAULT 0,

  -- Top categorías (denormalizado)
  -- [{ category_id, name, icon, amount, pct, tx_count, avg_per_tx }]
  top_categories jsonb NOT NULL DEFAULT '[]'::jsonb,

  -- Baselines per categoría (para anomaly detector)
  -- { "<category_id>": { avg: N, stddev: N, count: N, max: N } }
  category_baselines jsonb NOT NULL DEFAULT '{}'::jsonb,

  -- Patrones temporales
  peak_day_of_week int NULL,       -- 0=domingo, 6=sábado
  peak_week_of_month int NULL,     -- 1-4 (semana del mes)
  avg_by_weekday jsonb NOT NULL DEFAULT '{}'::jsonb,
  -- { "0": 25000, "1": 18000, ... }  gasto promedio por día de la semana

  -- Comportamientos detectados
  largest_expense jsonb NULL,
  -- { amount, merchant, date, category_id, tx_id }
  ant_expense_count int NOT NULL DEFAULT 0,     -- < $5k CLP
  ant_expense_total numeric NOT NULL DEFAULT 0,

  -- Procedencia del dataset
  sources jsonb NOT NULL DEFAULT '[]'::jsonb,
  -- [{ source: 'fintoc_initial'|'incremental'|'manual_recompute'|'batch_weekly',
  --    tx_count, period_start, period_end, computed_at }]

  -- Freshness
  tx_count_at_compute int NOT NULL DEFAULT 0,
  computed_at timestamptz NOT NULL DEFAULT now(),
  stale boolean NOT NULL DEFAULT false,
  schema_version int NOT NULL DEFAULT 1,

  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE user_insights ENABLE ROW LEVEL SECURITY;

CREATE POLICY user_insights_self ON user_insights
  FOR SELECT USING (user_id = auth.uid());
-- Escritura solo service_role (backend)

CREATE INDEX idx_user_insights_stale
  ON user_insights(stale, computed_at)
  WHERE stale = true;
```

### Historial opcional — `user_insights_history`

Snapshots temporales para trend tracking. No se consulta en hot path.

```sql
CREATE TABLE user_insights_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  snapshot jsonb NOT NULL,          -- clone completa de la fila de user_insights
  computed_at timestamptz NOT NULL DEFAULT now(),
  trigger_source text NOT NULL
  -- 'fintoc_initial'|'manual_recompute'|'monthly_archive'|'relinking'
);

CREATE INDEX idx_insights_history_user
  ON user_insights_history(user_id, computed_at DESC);

-- Auto-purge de history > 18 meses vía pg_cron semanal
```

Política: se escribe una fila en history cuando:
- Corre el compute inicial post-exchange
- Corre el recompute manual `/internal/insights/recompute`
- Corre el batch mensual de archivo (primer día de cada mes)
- Se re-linkea una cuenta (snapshot del estado previo)

Usos futuros (no MVP):
- "Cómo cambió tu patrón de gasto en los últimos 6 meses"
- Detección de drift (si avg_monthly_spend crece >30% mes a mes, alertar)

### Cache temporal — `fintoc_raw_cache`

Opcional pero recomendado para MVP. Permite re-computar insights si el
modelo mejora, sin volver a pagar calls a Fintoc.

```sql
CREATE TABLE fintoc_raw_cache (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  fintoc_link_id uuid NOT NULL REFERENCES fintoc_links(id) ON DELETE CASCADE,
  fintoc_account_id text NOT NULL,
  period_start date NOT NULL,
  period_end date NOT NULL,
  movements jsonb NOT NULL,         -- array crudo de Fintoc
  movements_count int NOT NULL,
  fetched_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '30 days'),
  UNIQUE (user_id, fintoc_account_id, period_start, period_end)
);

CREATE INDEX idx_fintoc_raw_cache_expires
  ON fintoc_raw_cache(expires_at);

ALTER TABLE fintoc_raw_cache ENABLE ROW LEVEL SECURITY;
CREATE POLICY raw_cache_self ON fintoc_raw_cache
  FOR SELECT USING (user_id = auth.uid());
-- Escritura solo service_role

-- Auto-purge vía pg_cron diario
-- DELETE FROM fintoc_raw_cache WHERE expires_at < now();
```

**Tamaño esperado:** ~200KB por user activo (promedio 400 movs en 90 días
con ~500 bytes cada uno). Para 1000 users = 200MB. Manejable.

---

## Insight Engine

Service unificado que toma una lista de transacciones y produce un row
de insights. Reutilizable para los 4 triggers.

### Ubicación

```
backend/src/insights/
├── insights.module.ts
├── insights-engine.service.ts      # Core: computeInsights(txs) → InsightResult
├── insights-writer.service.ts      # Upsert a user_insights + escribir history
├── insights-reader.service.ts      # Queries para features downstream
├── insights-recompute.service.ts   # Triggers #3 y #4 (batch + on-demand)
├── detectors/
│   ├── top-categories.ts
│   ├── baselines.ts
│   ├── temporal-patterns.ts
│   └── ant-expenses.ts
└── contracts/
    ├── insight-result.ts           # Shape del output
    └── insight-input.ts            # Shape del input (TransactionRow[])
```

### Contrato

```typescript
interface InsightInput {
  userId: string;
  transactions: TransactionRow[];    // ya filtradas por is_internal_transfer=false
  periodStart: Date;
  periodEnd: Date;
  source: 'fintoc_initial' | 'incremental' | 'manual_recompute' | 'batch_weekly';
}

interface InsightResult {
  avgMonthlySpend: number;
  avgMonthlyIncome: number;
  avgDailySpend: number;
  totalExpenseCount: number;
  topCategories: Array<{
    categoryId: string;
    name: string;
    icon: string | null;
    amount: number;
    pct: number;
    txCount: number;
    avgPerTx: number;
  }>;
  categoryBaselines: Record<string, {
    avg: number;
    stddev: number;
    count: number;
    max: number;
  }>;
  peakDayOfWeek: number | null;
  peakWeekOfMonth: number | null;
  avgByWeekday: Record<number, number>;
  largestExpense: {
    amount: number;
    merchant: string;
    date: string;
    categoryId: string | null;
    txId: string;
  } | null;
  antExpenseCount: number;
  antExpenseTotal: number;
  periodCovered: { start: Date; end: Date };
  txCountAtCompute: number;
}
```

### Pipeline interno

```typescript
async computeInsights(input: InsightInput): Promise<InsightResult> {
  const txs = input.transactions.filter(
    t => !t.is_internal_transfer && t.type === 'expense',
  );
  const incomes = input.transactions.filter(
    t => !t.is_internal_transfer && t.type === 'income',
  );

  const byCategory = groupByCategory(txs);
  const topCategories = pickTop(byCategory, 5);
  const baselines = computeBaselines(byCategory);
  const temporal = computeTemporalPatterns(txs);
  const ants = detectAntExpenses(txs, 5000);
  const largest = maxBy(txs, 'amount');

  const monthsCovered = monthsBetween(input.periodStart, input.periodEnd);
  const avgMonthlySpend = sum(txs, 'amount') / monthsCovered;
  const avgMonthlyIncome = sum(incomes, 'amount') / monthsCovered;

  return { /* ... */ };
}
```

Sin Gemini. Sin Redis. Solo JS determinista sobre un array. Testeable
unitariamente (aunque usemos bash integration para el flow completo).

---

## Lifecycle / Triggers

Los 4 caminos por los que `user_insights` se mantiene fresca.

### Trigger #1 — Initial Fintoc Exchange (compute completo)

Disparado al final de `FintocLinkService.exchange()`, tras persistir
accounts:

```typescript
// fintoc-link.service.ts, nuevo step post-exchange
const movements = await this.fintocApi.listAllMovementsForLink(
  linkToken,
  { since: ninetyDaysAgo, until: today },
);

// Cache raw en fintoc_raw_cache (opcional, 30d TTL)
await this.rawCache.store(userId, linkId, movements);

// Convertir Fintoc movements a shape de TransactionRow (sin insertar en DB)
const txRows = movements.map(m => this.toVirtualTransactionRow(m, accountId));

// Compute
const result = await this.insightsEngine.computeInsights({
  userId,
  transactions: txRows,
  periodStart: ninetyDaysAgo,
  periodEnd: today,
  source: 'fintoc_initial',
});

// Persistir
await this.insightsWriter.upsert(userId, result);
await this.insightsWriter.archiveToHistory(userId, result, 'fintoc_initial');

// Welcome report de Gus
await this.proactiveGus.sendInitialReport(userId, result);
```

**Importante:** `txRows` son objetos in-memory. **NO se insertan en la
tabla `transactions`**. El raw va opcional al cache, y el procesado va a
`user_insights`. Los 90 días no contaminan el historial del user.

### Trigger #2 — Incremental on new transaction

Cada vez que se inserta una tx nueva (bank_api o manual), el engine se
ejecuta **en modo incremental** — actualiza métricas running sin re-leer
90 días.

```typescript
// insights-engine.service.ts
async updateIncremental(userId: string, newTx: TransactionRow): Promise<void> {
  if (newTx.is_internal_transfer) return;

  const current = await this.reader.getOrInit(userId);
  const updated = this.applyIncrementalUpdate(current, newTx);
  await this.writer.upsert(userId, updated);
}

private applyIncrementalUpdate(
  current: InsightResult,
  tx: TransactionRow,
): InsightResult {
  // Running updates:
  // - total_expense_count++
  // - avg_daily_spend = (old_avg * old_n + tx.amount) / (old_n + 1)   // approx
  // - ant counters si corresponde
  // - largest_expense si tx.amount > current.largest.amount
  // - top_categories: actualizar amount del categoryId correspondiente
  //   (recomputar pct al final)
  // - avg_by_weekday[tx.day_of_week] += tx.amount / weeks_in_period
  // - category_baselines[catId]: Welford online (avg + stddev running)
  //
  // Triggear stale=true si discrepancia acumulada supera threshold.
  return updated;
}
```

**Tradeoff:** incrementales acumulan drift. Por eso existe el Trigger #3.

### Trigger #3 — Batch recompute semanal (failsafe)

`@nestjs/schedule` con `@Cron('0 3 * * 0')` (domingo 03:00 CLT). Para
cada user activo:

```typescript
const lastNinetyDays = await this.loadTransactions(userId, 90);
const result = await this.engine.computeInsights({
  userId,
  transactions: lastNinetyDays,
  periodStart: ninetyDaysAgo,
  periodEnd: today,
  source: 'batch_weekly',
});
await this.writer.upsert(userId, result);
```

Corrige el drift de los incrementales. Single-instance safe con
`SETNX insights:batch:{YYYY-MM-DD}` TTL 1h.

**Costo:** ~200 ms por user. 1000 users × 200ms = 3.3 min. Corre dentro
de la ventana de baja carga.

### Trigger #4 — On-demand recompute

Endpoint interno:

```
POST /internal/insights/recompute
  headers: Authorization: Bearer <service-token>
  body: { userId: uuid }
```

Usado cuando:
- Gus detecta inconsistencia (ej. user borró 50 tx en bulk)
- Admin lo dispara desde dashboard
- User pide "re-analizá mis datos" desde la UI

Rate limit: 3 recomputes/user/hora.

---

## Re-linking policy

Cuando un user re-linkea una cuenta Fintoc (mismo banco, misma cuenta o
una nueva), la decisión sobre qué hacer con `user_insights`:

| Caso | `sources` previo | Acción |
|---|---|---|
| Token expiró, re-auth silenciosa | Mismo link_id activo | Nada. Solo refresh link_token en vault. |
| Link revocado + re-conectado < 7d | Hay fintoc_initial reciente | Merge: recomputar 90 días, combinar con insights existentes (weighted average) |
| Link revocado + re-conectado > 7d | fintoc_initial viejo | Archivar a history con `trigger='relinking'`, sobrescribir row principal |
| Cuenta distinta, mismo banco | fintoc_initial de otra cuenta | Agregar nueva fuente a `sources`, recomputar incluyendo ambas |
| Cuenta distinta, banco distinto | Idem | Idem |

Implementación: en `FintocLinkService.exchange()`, antes de correr el
initial compute, chequear `user_insights.sources` del user:

```typescript
const existing = await this.insightsReader.get(userId);
const policy = this.decideRelinkingPolicy(existing, newLinkInfo);
// 'skip' | 'merge' | 'archive_and_replace' | 'add_source'
await this.insightsRecompute.run(userId, policy, newMovements);
```

---

## Integración con otros planes

### `PLAN_GUS_PROACTIVO.md`

**Fase 1 (nightly summary)**: reemplazar el SQL inline de 160 líneas por:

```sql
SELECT u.id, u.nickname, ui.avg_daily_spend, ui.top_categories,
       ui.category_baselines, up.notification_level, up.timezone,
       ps.tone, ps.mood
FROM users u
JOIN user_prefs up ON up.id = u.id
JOIN user_insights ui ON ui.user_id = u.id
LEFT JOIN personality_snapshot ps ON ps.user_id = u.id
WHERE up.notification_level IN ('light', 'medium', 'intense')
  AND u.onboarding_completed = true;
```

El template del mensaje lee `top_categories[0]` en vez de correr subquery.

**Fase 2 (anomaly detector)**: usar `category_baselines` directamente:

```typescript
const baseline = insights.category_baselines[tx.category_id];
const outlier = tx.amount > Math.max(2 * baseline.avg, 2 * baseline.stddev);
```

**Fase 4 (subscription detector)**: mantener la query SQL de 25-35d
(no cubierta por insights). Pero confirmed subscriptions aparecen en
`top_categories` con peso correcto.

### `PLAN_MERCHANT_RESOLVER.md`

La "Fase 4 Insight Engine" se **fusiona con este plan** — desaparece de
MERCHANT_RESOLVER, queda acá. MERCHANT_RESOLVER solo aporta el
`merchant_id` normalizado que este engine agrupa.

Actualización al plan viejo: cambiar "Fase 4 — Insight post-onboarding
(1 semana)" por "Fase 4 — Alimentar `user_insights` via merchant_id (ver
PLAN_USER_INSIGHTS.md)".

### `PLAN_ACCOUNT_TRANSFERS.md` (pendiente)

Este plan asume que cuando exista, `is_internal_transfer=true` estará
correctamente poblado y el engine filtrará automáticamente. Sin acción
adicional de nuestro lado.

---

## Welcome report — caso de uso de referencia

Flow completo post-`/exchange`:

1. `FintocLinkService.exchange()` termina de persistir accounts
2. Pull de 90 días vía `api.listMovements` (ya existente)
3. Cache raw en `fintoc_raw_cache` (opcional, 30d TTL)
4. `insightsEngine.computeInsights(virtualTxs)` → `InsightResult`
5. `insightsWriter.upsert(userId, result)` + archivo a history
6. `proactiveGus.sendInitialReport(userId, result)`:
   - Lee `user_insights` (mismo row recién escrito)
   - Arma el mensaje con el template del welcome report
   - Incluye 3 top categorías + avg_monthly_spend
   - Detector de suscripciones se ejecuta sobre los virtual txs,
     guarda candidatos en `recurring_charge_candidates`
   - Si hay candidatos → agregar sección con botones [Sí, agregar] [No]
7. User recibe mensaje, con callbacks que disparan siguientes acciones

**Importante:** la detección de suscripciones en el initial pull usa los
movimientos **virtuales in-memory** (no están en `transactions`). Por
eso, al confirmar, se crea un `spending_expectations` con los datos del
candidate, no con referencia al tx_id (que no existe en DB).

Cuando el segundo refresh traiga un cargo nuevo de esa misma
suscripción, SÍ va a `transactions` normalmente, y el detector del
refresh-time lo va a encontrar como "segunda ocurrencia en 30 días" —
pero el user ya lo confirmó como suscripción, entonces se dedupe vía
`recurring_charge_candidates.status='confirmed'`.

---

## Estimación de esfuerzo

| Fase | Trabajo | Tiempo |
|---|---|---|
| **F1 — Schema + transfer prep** | Migration con las 3 tablas + columnas en transactions + stub | 0.5 día |
| **F2 — Insight Engine core** | `insights-engine.service.ts` con 4 detectors + contratos | 1 día |
| **F3 — Writer + Reader** | Upsert + history + queries para downstream | 0.5 día |
| **F4 — Trigger #1 (initial)** | Hook en `FintocLinkService.exchange()` | 0.5 día |
| **F5 — Trigger #2 (incremental)** | Hook en `register-expense.fn.ts`, `register-income.fn.ts`, `FintocSyncService.persistMovements` | 0.5 día |
| **F6 — Trigger #3 (batch)** | `@Cron` job + SETNX lock | 0.5 día |
| **F7 — Trigger #4 (on-demand)** | Endpoint interno + rate limit | 0.5 día |
| **F8 — Re-linking policy** | `decideRelinkingPolicy()` + tests | 1 día |
| **F9 — Welcome report integration** | `proactiveGus.sendInitialReport()` + template | 0.5 día |
| **F10 — Integración con PLAN_GUS_PROACTIVO** | Refactor del nightly summary + anomaly detector para leer insights | 1 día |
| **F11 — Testing** | Bash integration para los 4 triggers + re-linking scenarios | 1 día |

**Total: ~8 días.** Puede hacerse en paralelo con MERCHANT_RESOLVER
(independientes hasta F10). Blocker de ambos planes posteriores.

---

## Testing strategy (bash integration)

```
backend/scripts/
├── test-insights-initial.sh        # Trigger #1
├── test-insights-incremental.sh    # Trigger #2
├── test-insights-batch.sh          # Trigger #3
├── test-insights-recompute.sh      # Trigger #4
├── test-insights-relinking.sh      # Re-linking policy (4 casos)
└── test-insights-integration.sh    # Welcome report end-to-end
```

Cada script:
1. Seed data vía SQL directo (bypass API)
2. Llamar el hook/endpoint relevante
3. Query `user_insights` y verificar shape + valores esperados
4. Verificar `bot_message_log` si aplica (welcome report)

No unit tests (feedback del user — preferencia del proyecto).

---

## Riesgos

| Riesgo | Severidad | Mitigación |
|---|---|---|
| Drift de incrementales (Welford no es exacto) | Media | Batch semanal corrige. Monitorear diferencia entre incremental y batch; si > 5% → alertar |
| `top_categories` grande si user tiene 50 categorías | Baja | Limitar a top 5 hard-coded. Si user quiere ver más, endpoint paginado |
| `fintoc_raw_cache` crece infinito si no purgeamos | Media | `pg_cron` diario DELETE expires_at < now(). Alertar si tabla > 1GB |
| Insight engine consume todos los CPU con 1000+ users en batch | Media | Batch corre 3am, ventana baja. Si crece, paralelizar con limit de 50 users concurrentes |
| Recompute on-demand se abusa → DOS | Baja | Rate limit 3/hora/user. Audit log de cada call |
| Schema change con data existente | Media | `schema_version` en row. Migration idempotente con `DEFAULT` en nuevas columnas |
| Welcome report manda un mensaje falso porque Fintoc devolvió 0 movs | Baja | Fallback: si `tx_count_at_compute < 20` → Gus dice "aún no tengo suficiente data, pero desde ya registro todo" |
| `category_baselines` invalidos cuando user renombra/borra categoría | Media | Invalidación vía trigger: `ALTER categories → mark user_insights.stale=true` |
| Transferencias contaminan insights pre-fix | Alta | Esperado hasta ACCOUNT_TRANSFERS. Documentar en UI: "estimaciones pueden incluir transferencias entre tus cuentas". Filtros listos para día 1 de ese plan |

---

## Decisiones abiertas

1. **¿`fintoc_raw_cache` sí o no en MVP?**
   - Sí: permite iterar el modelo sin volver a Fintoc. Cuesta ~200KB/user.
   - No: más limpio, pero cada iteración del modelo requiere re-pull.
   - **Recomendación:** sí por 3 meses, después evaluar.

2. **¿`user_insights_history` en MVP?**
   - Sí: agrega feature futura (trends) sin trabajo extra.
   - No: otra tabla que mantener.
   - **Recomendación:** sí, con purge 18 meses. Es barato.

3. **¿Qué hacer si user tiene < 20 txs totales?**
   - Opción A: no escribir row en `user_insights` (feature "insights" aparece como "aún no disponible")
   - Opción B: escribir row con métricas limitadas (solo avg_daily, no top_categories)
   - **Recomendación:** B con flag `insights.has_sufficient_data` en el row.

4. **¿Exponer endpoint público `GET /api/users/insights`?**
   - Sí: frontend puede mostrar una pestaña "Tus insights"
   - No: solo Gus lo consume
   - **Recomendación:** sí, JWT-protegido, devuelve versión "pública" del row (sin `category_baselines` que es infra interna).

5. **¿Qué pasa si dos triggers corren simultáneamente para el mismo user?**
   - Opción A: Redis lock por user (`insights:lock:{userId}`)
   - Opción B: última escritura gana (confiando en idempotencia del engine)
   - **Recomendación:** A. Lock TTL 30s, queue behind si busy.

---

## Criterio de done

- **F1-F3 (schema + engine + IO)**: migration corrida, insights engine
  produce output correcto sobre fixture de 100 txs.
- **F4-F7 (triggers)**: cada trigger escribe correctamente, verificable
  con bash integration.
- **F8 (re-linking)**: los 4 escenarios de re-link dan resultado correcto.
- **F9-F10 (integración)**: `PLAN_GUS_PROACTIVO` Fase 1 corriendo en prod
  con queries contra `user_insights`, no SQL agregado inline.
- **F11 (testing)**: los 6 scripts pasan, corren en CI.
- **Métricas baseline capturadas**: promedio de tamaño de `top_categories`
  por user, drift de incrementales vs batch, costo Gemini del welcome
  report.

---

## Dependencias futuras

- **`PLAN_ACCOUNT_TRANSFERS.md`** (bloqueante para insights 100% correctos)
- **`PLAN_MERCHANT_RESOLVER.md`** (mejora la agrupación de `top_categories`
  al tener merchants canónicos, pero no bloquea)
- **`PLAN_GUS_PROACTIVO.md`** (dependiente — Fases 1, 2 consumen insights)

---

## Log de cambios

- `2026-04-21` — Documento inicial (Sebastián + Claude).
